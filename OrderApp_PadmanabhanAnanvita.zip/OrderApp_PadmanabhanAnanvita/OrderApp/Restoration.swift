//
//  Restoration.swift
//  OrderApp
//
//  Created by Ananvita Padmanabhan - 191324 on 03/20/24.
//

import Foundation

// This extension of NSUserActivity provides several properties to contain state information
extension NSUserActivity {
    
    // The user's current order
    var order: Order? {
        
        // Decode the order data
        get {
            guard let jsonData = userInfo?["order"] as? Data else { return nil }
            return try? JSONDecoder().decode(Order.self, from: jsonData)
        }
        
        // Encode the order data
        set {
            if let newValue = newValue, let jsonData = try? JSONEncoder().encode(newValue) {
                addUserInfoEntries(from: ["order": jsonData])
            } else {
                userInfo?["order"] = nil
            }
        }
    }
    
    // The user's currently presented view controller
    var controllerIdentifier: StateRestorationController.Identifier? {
        
        // Fetch the controllerIdentifier data
        get {
            if let controllerIdentifier = userInfo?["controllerIdentifier"] as? String {
                return StateRestorationController.Identifier(rawValue: controllerIdentifier)
            } else {
                return nil
            }
        }
        
        // Set the controllerIdentifier data
        set {
            userInfo?["controllerIdentifier"] = newValue?.rawValue
        }
    }
    
    // The user's currently selected menu category
    var menuCategory: String? {
        
        // Fetch the menuCategory data
        get {
            return userInfo?["menuCategory"] as? String
        }
        
        // Set the menuCategory data
        set {
            userInfo?["menuCategory"] = newValue
        }
    }
    
    // The user's currently selected menu item
    var menuItem: MenuItem? {
        
        // Decode the menuItem data
        get {
            guard let jsonData = userInfo?["menuItem"] as? Data else { return nil }
            return try? JSONDecoder().decode(MenuItem.self, from: jsonData)
        }
        
        // Encode the data
        set {
            if let newValue = newValue, let jsonData = try? JSONEncoder().encode(newValue) {
                addUserInfoEntries(from: ["menuItem": jsonData])
            } else {
                userInfo?["menuItem"] = nil
            }
        }
    }
}

// This enum contains the possible state restoration views to be restored
enum StateRestorationController {
    
    // Initialize with stored userActivity, if it exists
    init?(userActivity: NSUserActivity) {
        guard let identifier = userActivity.controllerIdentifier else { return nil }
        
        switch identifier {
        case .categories:
            self = .categories
        case .menu:
            if let category = userActivity.menuCategory {
                self = .menu(category: category)
            } else {
                return nil
            }
        case .menuItemDetail:
            if let menuItem = userActivity.menuItem {
                self = .menuItemDetail(menuItem)
            } else {
                return nil
            }
        case .order:
            self = .order
        }
    }
    
    // This enum provides options for the view currently in use
    enum Identifier: String {
        case categories, menu, menuItemDetail, order
    }
    
    case categories
    case menu(category: String)
    case menuItemDetail(MenuItem)
    case order
    
    // Keep track of the view currently in use
    var identifier: Identifier {
        switch self {
        case .categories: return Identifier.categories
        case .menu: return Identifier.menu
        case .menuItemDetail: return Identifier.menuItemDetail
        case .order: return Identifier.order
        }
    }
}
