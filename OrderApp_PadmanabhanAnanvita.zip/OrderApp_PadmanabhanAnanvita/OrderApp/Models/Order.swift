//
//  Order.swift
//  OrderApp
//
//  Created by Ananvita Padmanabhan - 191324 on 03/20/24.
//

import Foundation

// This struct is a model for an order of one or more menu items
struct Order: Codable {
    var menuItems: [MenuItem]
    
    init(menuItems: [MenuItem] = []) {
        self.menuItems = menuItems
    }
}
